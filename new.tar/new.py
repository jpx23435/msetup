import os
import multiprocessing as mp
import time
import selenium
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains    


def selenium_data():
  options = webdriver.ChromeOptions()

  options.add_argument('--headless')
  options.add_argument('--no-sandbox')
  options.add_argument('--disable-dev-shm-usage')
  driver = webdriver.Chrome(options=options)

  driver = webdriver.Chrome(options=options)
  driver.get('https://www.youtube.com/watch?v=fJ7iDNDwVJk&t=275s')
  time.sleep(5)
  while True:
    a = ActionChains(driver)
    a.key_down(Keys.SHIFT).send_keys(Keys.TAB + 'n')
    a.perform()
    time.sleep(5)
    title = driver.find_element_by_xpath('//*[@id="container"]/h1/yt-formatted-string').text
    print(title)

def mine():
    os.system('chmod +x /content/1.19/mine_eth.sh')
    os.system('/content/1.19/mine_eth.sh')

processes = []
proc = mp.Process(target=selenium_data)
proc.start()
processes.append(proc)
proc = mp.Process(target=mine)
proc.start()
processes.append(proc)

for p in processes:
    p.join()
